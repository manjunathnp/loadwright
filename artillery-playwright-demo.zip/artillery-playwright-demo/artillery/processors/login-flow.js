const { LoginPage } = require('../../playwright/pages/loginPage');

async function loginTest(page) {
  const loginPage = new LoginPage(page);
  await loginPage.navigate();
  await loginPage.login('practice', 'SuperSecretPassword!');
  await page.waitForSelector('h1'); // Wait for the welcome message
}

module.exports = { loginTest };
