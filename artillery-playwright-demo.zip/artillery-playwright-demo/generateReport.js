// generateReport.js

const fs = require('fs');
const path = require('path');

const reportsDir = path.resolve(__dirname, 'reports');
const reportFiles = fs.readdirSync(reportsDir)
  .filter(file => file.endsWith('.json'))
  .map(file => ({ file, time: fs.statSync(path.join(reportsDir, file)).mtime.getTime() }))
  .sort((a, b) => b.time - a.time)
  .slice(0, 3)
  .map(entry => path.join(reportsDir, entry.file));

function extractMetrics(jsonPath) {
  const data = JSON.parse(fs.readFileSync(jsonPath, 'utf-8'));
  const counters = data.aggregate?.counters || {};
  const summaries = data.aggregate?.summaries || {};

  // return {
  //   'Virtual Users Created': counters['vusers.created'] ?? 0,
  //   'Virtual Users Completed': counters['vusers.completed'] ?? 0,
  //   'Responses (200)': counters['browser.page.codes.200'] ?? 0,
  //   'Responses (400)': counters['browser.page.codes.400'] ?? 0,
  //   'Responses (500)': counters['browser.page.codes.500'] ?? 0,
  //   'HTTP Requests': counters['browser.http_requests'] ?? 0,
  //   'TTFB (Mean)': summaries['browser.page.TTFB.https://practice.expandtesting.com/login']?.mean ?? 0,
  //   'FCP (Mean)': summaries['browser.page.FCP.https://practice.expandtesting.com/login']?.mean ?? 0,
  //   'LCP (Mean)': summaries['browser.page.LCP.https://practice.expandtesting.com/login']?.mean ?? 0,
  //   'INP (Mean)': summaries['browser.page.INP.https://practice.expandtesting.com/login']?.mean ?? 0,
  //   'FID (Mean)': summaries['browser.page.FID.https://practice.expandtesting.com/login']?.mean ?? 0,
  //   'CLS (Mean)': summaries['browser.page.CLS.https://practice.expandtesting.com/login']?.mean ?? 0,
  //   'Session Length (Mean)': summaries['vusers.session_length']?.mean ?? 0,
  // };

  return {
    'Virtual Users Created': counters['vusers.created'] ?? 0,
    'Virtual Users Completed': counters['vusers.completed'] ?? 0,
    'Responses (200)': counters['browser.page.codes.200'] ?? 0,
    'Responses (400)': counters['browser.page.codes.400'] ?? 0,
    'Responses (500)': counters['browser.page.codes.500'] ?? 0,
    'HTTP Requests': counters['browser.http_requests'] ?? 0,
    'TTFB (Mean)': summaries['browser.page.TTFB.https://www.saucedemo.com/']?.mean ?? 0,
    'FCP (Mean)': summaries['browser.page.FCP.https://www.saucedemo.com/']?.mean ?? 0,
    'LCP (Mean)': summaries['browser.page.LCP.https://www.saucedemo.com/']?.mean ?? 0,
    'INP (Mean)': summaries['browser.page.INP.https://www.saucedemo.com/']?.mean ?? 0,
    'FID (Mean)': summaries['browser.page.FID.https://www.saucedemo.com/']?.mean ?? 0,
    'CLS (Mean)': summaries['browser.page.CLS.https://www.saucedemo.com/']?.mean ?? 0,
    'Session Length (Mean)': summaries['vusers.session_length']?.mean ?? 0,
  };
}


function getEmoji(metric, value) {
  const rule = expected[metric];
  if (!rule || rule === '-') return '✅';

  const cleanValue = typeof value === 'string' ? parseFloat(value) : value;

  if (rule.includes('<=') && cleanValue > parseFloat(rule.replace('<=', ''))) return '🔴';
  if (rule.includes('<') && cleanValue >= parseFloat(rule.replace('<', ''))) return '🔴';
  if (rule.includes('>=') && cleanValue < parseFloat(rule.replace('>=', ''))) return '🔴';
  if (rule.includes('>') && cleanValue <= parseFloat(rule.replace('>', ''))) return '🔴';
  if (rule.includes('==') && cleanValue !== parseFloat(rule.replace('==', ''))) return '🔴';
  if (rule.includes('=') && rule.includes('Virtual Users Created')) return '✅';

  return '✅';
}

const expected = {
  'Virtual Users Created': '>= 60',
  'Virtual Users Completed': '= Virtual Users Created',
  'Responses (200)': '>= 2500',
  'Responses (400)': '== 0',
  'Responses (500)': '== 0',
  'HTTP Requests': '>= 3000',
  'TTFB (Mean)': '< 1000',
  'FCP (Mean)': '< 3000',
  'LCP (Mean)': '< 3000',
  'INP (Mean)': '<= 50',
  'FID (Mean)': '<= 1',
  'CLS (Mean)': '<= 0.1',
  'Session Length (Mean)': '< 20000',
};

const metricLabels = Object.keys(extractMetrics(reportFiles[0]));
const datasets = [];
const allRuns = [];

reportFiles.forEach((file, index) => {
  const metrics = extractMetrics(file);
  const values = metricLabels.map(label => metrics[label]);
  const colors = metricLabels.map(label => getEmoji(label, metrics[label]) === '✅' ? '#2ecc71' : '#e74c3c');

  datasets.push({
    label: `Run ${index + 1}`,
    data: values,
    backgroundColor: colors,
  });

  allRuns.push({
    name: `Run ${index + 1}`,
    metrics,
  });
});

let tableHTML = `<table border="1" cellpadding="10" cellspacing="0">
<tr><th>Metric</th><th>Expected</th>${allRuns.map(r => `<th>${r.name}</th>`).join('')}</tr>`;
metricLabels.forEach(label => {
  tableHTML += `<tr><td>${label}</td><td>${expected[label] ?? '-'}</td>` +
    allRuns.map(r => `<td>${r.metrics[label]} ${getEmoji(label, r.metrics[label])}</td>`).join('') +
    `</tr>`;
});
tableHTML += '</table>';

const html = `
<!DOCTYPE html>
<html>
<head>
  <title>Artillery Trend Report</title>
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <style>
    body { font-family: Arial, sans-serif; padding: 20px; background: #f9f9f9; }
    h1 { color: #2c3e50; }
    canvas { margin-top: 40px; max-width: 100%; height: 400px; }
    table { width: 100%; border-collapse: collapse; margin-top: 30px; }
    th { background-color: #f0f0f0; }
    td, th { padding: 8px; text-align: left; }
  </style>
</head>
<body>
  <div id="report">
    <h1>Performance Trend Comparison</h1>
    <canvas id="trendChart"></canvas>
    ${tableHTML}
  </div>

  <script>
    const ctx = document.getElementById('trendChart').getContext('2d');
    new Chart(ctx, {
      type: 'bar',
      data: {
        labels: ${JSON.stringify(metricLabels)},
        datasets: ${JSON.stringify(datasets)}
      },
      options: {
        responsive: true,
        plugins: {
          legend: { position: 'top' },
          title: { display: true, text: 'Metric Trends Across Runs' }
        },
        scales: {
          y: {
            beginAtZero: true,
            ticks: {
              callback: function(value) {
                return value >= 1000 ? value.toLocaleString() : value;
              }
            }
          }
        }
      }
    });
  </script>

  <div style="margin-top: 60px;">
    <details>
      <summary style="font-size: 1.2em; font-weight: bold;">📘 Glossary of Metrics & Expected Values</summary>
      <div style="padding: 10px;">
        <table border="1" cellpadding="8" cellspacing="0">
          <tr><th>Metric</th><th>Meaning</th><th>Expected</th></tr>
          <tr><td>Virtual Users Created</td><td>Number of simulated users that started the test</td><td>&ge; 60</td></tr>
          <tr><td>Virtual Users Completed</td><td>Number of users who completed all test steps</td><td>= Virtual Users Created</td></tr>
          <tr><td>Responses (200)</td><td>Count of successful requests (OK status)</td><td>&ge; 2500</td></tr>
          <tr><td>Responses (400)</td><td>Count of client-side errors (e.g., invalid URL, bad request)</td><td>== 0</td></tr>
          <tr><td>Responses (500)</td><td>Count of server-side errors (e.g., crash, internal server error)</td><td>== 0</td></tr>
          <tr><td>HTTP Requests</td><td>Total number of HTTP requests made by all users</td><td>&ge; 3000</td></tr>
          <tr><td>TTFB (Mean)</td><td>⏱️ Time to First Byte – how fast the server starts responding (lower = better)</td><td>&lt; 1000 ms</td></tr>
          <tr><td>FCP (Mean)</td><td>⏱️ First Contentful Paint – when the first content appears on the screen</td><td>&lt; 3000 ms</td></tr>
          <tr><td>LCP (Mean)</td><td>⏱️ Largest Contentful Paint – when the largest visual element appears (image/text block)</td><td>&lt; 3000 ms</td></tr>
          <tr><td>INP (Mean)</td><td>⏱️ Interaction to Next Paint – how long it takes to update UI after user input</td><td>&le; 50 ms</td></tr>
          <tr><td>FID (Mean)</td><td>⏱️ First Input Delay – delay between user interaction and browser processing</td><td>&le; 1 ms</td></tr>
          <tr><td>CLS (Mean)</td><td>📉 Cumulative Layout Shift – measures visual stability (lower = less layout jumping)</td><td>&le; 0.1</td></tr>
          <tr><td>Session Length (Mean)</td><td>⏳ Average duration a user session took to complete</td><td>&lt; 20000 ms</td></tr>
        </table>
      </div>
    </details>
  </div>

</body>
</html>
`;

const outputPath = path.join(reportsDir, 'trend-report.html');
fs.writeFileSync(outputPath, html);
console.log(`✅ Trend comparison report generated: ${outputPath}`);
