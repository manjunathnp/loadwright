const fs = require('fs');
const path = require('path');

const now = new Date();
const timestamp = now.toISOString().replace(/[:.]/g, '-');
const outputDir = path.resolve(__dirname, 'reports');

if (!fs.existsSync(outputDir)) {
  fs.mkdirSync(outputDir);
}

const envFile = path.resolve(__dirname, '.env.report-path');
fs.writeFileSync(envFile, `REPORT_NAME=reports/report-${timestamp}.json\n`);
