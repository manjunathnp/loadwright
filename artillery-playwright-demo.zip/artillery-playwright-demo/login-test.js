// login-test.js
// async function loginTest(page) {
//     // await page.goto('https://practice.expandtesting.com/login');

//     await page.goto('https://practice.expandtesting.com/login', {
//       waitUntil: 'domcontentloaded',  // or 'networkidle' if needed
//       timeout: 60_000  // or reduce to 15000 if desired
//     });

//     await page.fill('#username', 'practice');
//     await page.fill('#password', 'SuperSecretPassword!');
//     await page.click('button[type="submit"]');
//     await page.waitForSelector('h1'); // Confirm successful login
//   }
  
async function loginTest(page) {
  // await page.goto('https://practice.expandtesting.com/login');

  await page.goto('https://www.saucedemo.com/', {
    waitUntil: 'domcontentloaded',  // or 'networkidle' if needed
    timeout: 60_000  // or reduce to 15000 if desired
  });

  await page.fill('#user-name', 'standard_user');
  await page.fill('#password', 'secret_sauce!');
  await page.click('#login-button');
  //await page.waitForSelector('h1'); // Confirm successful login
}
  module.exports = { loginTest };
  