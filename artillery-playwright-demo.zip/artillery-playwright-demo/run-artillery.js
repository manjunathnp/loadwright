const dotenv = require('dotenv');
const { execSync } = require('child_process');

dotenv.config({ path: '.env.report-path' });

const outputPath = process.env.REPORT_NAME;

try {
  execSync(`npx artillery run login-test.yml --output ${outputPath}`, {
    stdio: 'inherit'
  });
  console.log(`✅ Saved report to ${outputPath}`);
} catch (err) {
  console.error('❌ Failed to run Artillery:', err.message);
  process.exit(1);
}
